package jdbc;
import java.sql.*;
public class Librarian {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Connection myConn = null;
		Statement myStmt = null;
		ResultSet myRs = null;
		
		try {
			// 1. Get a connection to database
myConn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC", "root" , "Ta123456");
			
			// 2. Create a statement
			myStmt = myConn.createStatement();
			
			// 3. Execute SQL query
			myRs = myStmt.executeQuery("select * from librarian_view");
			
			// 4. Process the result set
			while (myRs.next()) {
				System.out.println(myRs.getString("name") + ", " + myRs.getString("title")+ ", " + myRs.getString("start_date")+ ", " + myRs.getString("end_date"));
			}
			
			String sql = "update librarian_view set name='s' where id=9";
			 
            int rowsAffected = myStmt.executeUpdate(sql);
 
            System.out.println("Rows affected: " + rowsAffected);
            System.out.println("Update complete.");
//			String sql = "insert into librarian_view " + " (name, first_name, email)"
//                    + " values ('Brown', 'David', 'david.brown@foo.com')";
// 
//            myStmt.executeUpdate(sql);
// 
//            System.out.println("Insert complete.");
			
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
		finally {
			if (myRs != null) {
				myRs.close();
			}
			
			if (myStmt != null) {
				myStmt.close();
			}
			
			if (myConn != null) {
				myConn.close();
			}
		}
	}
}
