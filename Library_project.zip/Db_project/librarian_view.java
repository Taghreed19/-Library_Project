package jdbc;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.sql.*;

import javax.swing.JOptionPane;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
//import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Component;
import javax.swing.Box;
import java.awt.Color;
import javax.swing.JFrame;

public class librarian_view {

	private JFrame frame;
	private JTextField endDate;
	private JTextField BID;
	private JTextField booktitle;
	private JTextField Bid;
	private JTextField BOOKTITLE;
	private JTextField START;
	private JTextField END;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					librarian_view window = new librarian_view();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public librarian_view() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(400, 900,550, 750);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Retrieve by end date");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
				String end=endDate.getText();
				
				Connection myConn=DriverManager.getConnection("?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC","root" ,"Ta123456");	
				//Connection myConn=getConnection();
				
				
				Statement myStmt= myConn.createStatement();
				ResultSet myRs=myStmt.executeQuery("SELECT * FROM librarian_view WHERE end_date = '"+end+"'");
				
			
				
				String s="------------------------------------\n";
				
				while(myRs.next()) {
					s+="First name: "+myRs.getString("name")+"\n"+"Book title: "+myRs.getString("title")+"\n"+"Insurance: "+myRs.getString("Insurance")+"\n";
					s+="------------------------------------\n";
				}
			
				JOptionPane.showMessageDialog(null,s);
				}catch(Exception e1) {

					JOptionPane.showMessageDialog(null,"error");	
				}	}
			
		});
		btnNewButton.setBounds(15, 32, 193, 73);
		frame.getContentPane().add(btnNewButton);
		
		endDate = new JTextField();
		endDate.setBounds(242, 38, 219, 61);
		frame.getContentPane().add(endDate);
		endDate.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Enter end date");
		lblNewLabel.setBounds(242, 16, 193, 20);
		frame.getContentPane().add(lblNewLabel);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBounds(-10, 123, 688, 51);
		frame.getContentPane().add(horizontalStrut);
		
		JButton btnDeleteBorrower = new JButton("Return book");
		btnDeleteBorrower.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
try {
					
					String id=	BID.getText();
					String add=booktitle.getText();
					
					
					
					Connection myConn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC","root" ,"Ta123456");	
					Statement myStmt= myConn.createStatement();
					
					// delete borrower from table borrow_by 
					String delete="delete from borrow_by where B_ID='"+id+"'and ISBN=(select ISBN from book where title = '"+add+"');";
					myStmt.executeUpdate(delete);
					// uptdete the number of book 
				
                      ResultSet myRs=myStmt.executeQuery("select num_of_book from book where title = '"+add+"';");
					
					String s="";
					//int d=Integer.parseInt(myRs.getString("num_of_book"))+1;
					//System.out.println(d);
					while(myRs.next()) {
						int d=Integer.parseInt(myRs.getString("num_of_book"));
						d+=1;

						s=""+d;
						
					}  
					//JOptionPane.showMessageDialog(null,s);
					String update="update book set num_of_book= '"+s+"'where title = '"+add+"';";
				myStmt.executeUpdate(update);
                   
					
					JOptionPane.showMessageDialog(null,"The address of employee with ID: "+id+"\nhas been returned ");
					
					}catch(Exception e1) {

						JOptionPane.showMessageDialog(null,"ERROR OCCURE ");		
					}	
			}
		});
		btnDeleteBorrower.setBounds(15, 175, 193, 73);
		frame.getContentPane().add(btnDeleteBorrower);
		
		JLabel lblEnterBorrowerId = new JLabel("Enter borrower ID");
		lblEnterBorrowerId.setBounds(242, 175, 193, 20);
		frame.getContentPane().add(lblEnterBorrowerId);
		
		BID = new JTextField();
		BID.setColumns(10);
		BID.setBounds(242, 198, 219, 61);
		frame.getContentPane().add(BID);
		
		booktitle = new JTextField();
		booktitle.setColumns(10);
		booktitle.setBounds(242, 287, 219, 61);
		frame.getContentPane().add(booktitle);
		
		JLabel lblEnterBookTitle = new JLabel("Enter book title");
		lblEnterBookTitle.setBounds(242, 264, 193, 20);
		frame.getContentPane().add(lblEnterBookTitle);
		
		JButton in = new JButton("Borrow book");
		in.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
try {
					
					String id=	Bid.getText();
					String add=BOOKTITLE.getText();
					String STA=START.getText();
					String EN=END.getText();
					
					
					
					Connection myConn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC","root" ,"Ta123456");	
					Statement myStmt= myConn.createStatement();
					ResultSet myRs=myStmt.executeQuery("select ISBN from book where title = '"+add+"';");
					
					
					
					String s="";
					
					while(myRs.next()) {
						s=myRs.getString("ISBN");
						
					}
					//delete from borrow_by where B_ID='0000000111' and ISBN=(select ISBN from book where title = 'DISCRETE MATHMATICS')
					//INSERT INTO BORROW_BY VALUES ('0000000113','000000004','2019-8-20','2019-12-3');
					String INSERT="INSERT INTO BORROW_BY VALUES('"+id+"','"+s+"','"+STA+"','"+EN+"')";
					myStmt.executeUpdate(INSERT);
					
ResultSet myRs1=myStmt.executeQuery("select num_of_book from book where title = '"+add+"';");
					
					String s1="";
					//int d=Integer.parseInt(myRs.getString("num_of_book"))+1;
					//System.out.println(d);
					while(myRs1.next()) {
						int d=Integer.parseInt(myRs1.getString("num_of_book"));
						d--;

						s1=""+d;
						
					}  
					//JOptionPane.showMessageDialog(null,s);
					String update="update book set num_of_book= '"+s+"'where title = '"+add+"';";
				myStmt.executeUpdate(update);
					
					JOptionPane.showMessageDialog(null,"The opration successed ");
					
					}catch(Exception e1) {

						JOptionPane.showMessageDialog(null,"ERROR OCURE ");		
					}
			}
		});
		in.setBounds(15, 396, 193, 73);
		frame.getContentPane().add(in);
		
		JLabel label = new JLabel("Enter borrower ID");
		label.setBounds(15, 485, 193, 20);
		frame.getContentPane().add(label);
		
		Bid = new JTextField();
		Bid.setColumns(10);
		Bid.setBounds(15, 509, 219, 61);
		frame.getContentPane().add(Bid);
		
		JLabel label_1 = new JLabel("Enter book title");
		label_1.setBounds(15, 584, 193, 20);
		frame.getContentPane().add(label_1);
		
		BOOKTITLE = new JTextField();
		BOOKTITLE.setColumns(10);
		BOOKTITLE.setBounds(15, 620, 219, 61);
		frame.getContentPane().add(BOOKTITLE);
		
		Component horizontalStrut_1 = Box.createHorizontalStrut(20);
		horizontalStrut_1.setBounds(-97, 353, 688, 51);
		frame.getContentPane().add(horizontalStrut_1);
		
		START = new JTextField();
		START.setColumns(10);
		START.setBounds(279, 509, 219, 61);
		frame.getContentPane().add(START);
		
		END = new JTextField();
		END.setColumns(10);
		END.setBounds(279, 620, 219, 61);
		frame.getContentPane().add(END);
		
		JLabel lblEnterStartDate = new JLabel("Enter start date");
		lblEnterStartDate.setBounds(279, 485, 193, 20);
		frame.getContentPane().add(lblEnterStartDate);
		
		JLabel label_3 = new JLabel("Enter end date");
		label_3.setBounds(279, 597, 193, 20);
		frame.getContentPane().add(label_3);
	}
}
