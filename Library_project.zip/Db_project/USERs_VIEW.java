package jdbc;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JComboBox;
import java.awt.Label;
import java.awt.Button;
import javax.swing.*;    
import java.awt.event.*;    

public class USERs_VIEW {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					USERs_VIEW window = new USERs_VIEW();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public USERs_VIEW() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		String views[]={"Librarian view","Administrator view"};
		JComboBox comboBox = new JComboBox(views);
		comboBox.setToolTipText("");
		comboBox.setBounds(82, 98, 254, 26);
		frame.getContentPane().add(comboBox);
		
		Label label = new Label(" Select user view");
		label.setBounds(82, 65, 137, 27);
		frame.getContentPane().add(label);
		
		Button button = new Button("show");
		button.setBounds(162, 207, 91, 27);
		frame.getContentPane().add(button);
		
		button.addActionListener(new ActionListener() {  
	        public void actionPerformed(ActionEvent e) {
	        	int s=comboBox.getSelectedIndex();
	        	comboBox.getItemAt(comboBox.getSelectedIndex());  
	        	if(s==0)
	        		librarian_view.main(new String [] {});	
	        	else
	        		administrator_view.main(new String [] {});
	        	}  
	        	});           
	        }
	}

