package jdbc;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.sql.*;

import javax.swing.JOptionPane;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
//import com.jgoodies.forms.factories.DefaultComponentFactory;
import java.awt.Component;
import javax.swing.Box;
import java.awt.Color;
public class administrator_view {

	private JFrame frame;
	private JTextField ID;
	private JTextField address;
	private JTextField newID;
	private JTextField ID2;
	private JTextField newAdd;
	private JTextField fname;
	private JTextField lname;
	private JTextField phone;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					administrator_view window = new administrator_view();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public administrator_view() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(400, 400, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		ID = new JTextField();
		ID.setBounds(270, 34, 158, 40);
		frame.getContentPane().add(ID);
		ID.setColumns(10);
		
		ID2 = new JTextField();
		ID2.setColumns(10);
		ID2.setBounds(222, 138, 158, 40);
		frame.getContentPane().add(ID2);
		
		address = new JTextField();
		address.setBounds(392, 138, 158, 40);
		frame.getContentPane().add(address);
		address.setColumns(10);

		lname = new JTextField();
		lname.setColumns(10);
		lname.setBounds(184, 299, 158, 40);
		frame.getContentPane().add(lname);
		
		phone = new JTextField();
		phone.setColumns(10);
		phone.setBounds(348, 299, 158, 40);
		frame.getContentPane().add(phone);
		
		fname = new JTextField();
		fname.setColumns(10);
		fname.setBounds(348, 243, 158, 40);
		frame.getContentPane().add(fname);
		newAdd = new JTextField();
		newAdd.setColumns(10);
		newAdd.setBounds(270, 366, 158, 40);
		frame.getContentPane().add(newAdd);
		newID = new JTextField();
		newID.setColumns(10);
		newID.setBounds(184, 243, 158, 40);
		frame.getContentPane().add(newID);
		
		
		JButton btnRetrieve = new JButton("Retrieve");
		btnRetrieve.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String id=ID.getText();
					
					Connection myConn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC","root" ,"Ta123456");	
					//Connection myConn=getConnection();
					
					
					Statement myStmt= myConn.createStatement();
					ResultSet myRs=myStmt.executeQuery("SELECT * FROM ADMINISTRATOR_VIEW WHERE ID = "+id);
					
				
					
					String s="";
					
					while(myRs.next()) {
						s="First name: "+myRs.getString("fname")+"\n"+"Last name: "+myRs.getString("lname")+"\n"+"Secteion name: "+myRs.getString("name")+"\n";
						
					}
				
					JOptionPane.showMessageDialog(null,s);
					}catch(Exception e1) {

						JOptionPane.showMessageDialog(null,"error");	
					}	
				
			}
		});
		btnRetrieve.setBounds(21, 41, 117, 29);
		frame.getContentPane().add(btnRetrieve); //
		
		JButton btnUpdate = new JButton("Update Address");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					String id=	ID2.getText();
					String add=address.getText();
					
					
					
					Connection myConn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC","root" ,"Ta123456");	
					Statement myStmt= myConn.createStatement();
					
					//String update=" update ADMINISTRATOR_VIEW "+" set address='90' "+"  where ID='1234567892'; ";
					
					String update=" update employee"+" set address = '"+add+"'  where ID='"+id+"';";
					myStmt.executeUpdate(update);
					
					JOptionPane.showMessageDialog(null,"The address of employee with ID: "+id+"\nhas been updated");
					
					}catch(Exception e1) {

						JOptionPane.showMessageDialog(null,"not updated");		
					}	
				
			}
		});
		btnUpdate.setBounds(21, 132, 117, 55);
		frame.getContentPane().add(btnUpdate);
		
		JButton btnNewButton = new JButton("Insert");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String fname1=fname.getText();
					String lname1=lname.getText();
					String newid=newID.getText();
					String add=newAdd.getText();
					String pho=phone.getText();
					
				Connection myConn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/library?useUnicode=true&characterEncoding=utf8&useSSL=false&useLegacyDatetimeCode=false&serverTimezone=UTC","root" ,"Ta123456");	
				Statement myStmt= myConn.createStatement();
				
				//String update=" update ADMINISTRATOR_VIEW "+" set address='90' "+"  where ID='1234567892'; ";
				//insert into Employee(ID,fname,lname,phone, address) values (); 
				String insert="insert into Employee(ID,fname,lname,phone, address) values ( '"+newid+"','"+fname1+"','"+lname1+"',"+pho+",'"+add+"');";
				myStmt.executeUpdate(insert);
				
				JOptionPane.showMessageDialog(null,"The  employee has been inserted");
				
				}catch(Exception e1) {

					JOptionPane.showMessageDialog(null,"not inserted");	
				}	
			
		
			}
		});
		btnNewButton.setBounds(21, 238, 117, 29);
		frame.getContentPane().add(btnNewButton);
		
		
		
		
		
		JLabel lblNewLabel = new JLabel("Enter ID of employee");
		lblNewLabel.setBounds(270, 19, 185, 16);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblEnterAddressOf = new JLabel("Enter the new address ");
		lblEnterAddressOf.setBounds(396, 110, 185, 16);
		frame.getContentPane().add(lblEnterAddressOf);
		
		
		
		//JLabel lblNewJgoodiesTitle = DefaultComponentFactory.getInstance().createTitle("New JGoodies title");
		//lblNewJgoodiesTitle.setBounds(279, 219, 122, 16);
		//frame.getContentPane().add(lblNewJgoodiesTitle);
		
		Component horizontalStrut = Box.createHorizontalStrut(20);
		horizontalStrut.setBackground(Color.DARK_GRAY);
		horizontalStrut.setBounds(0, 86, 714, 22);
		frame.getContentPane().add(horizontalStrut);
		
		Component horizontalStrut_1 = Box.createHorizontalStrut(20);
		horizontalStrut_1.setBackground(Color.DARK_GRAY);
		horizontalStrut_1.setBounds(0, 185, 720, 22);
		frame.getContentPane().add(horizontalStrut_1);
		
	
		
		JLabel label = new JLabel("Enter ID of employee");
		label.setBounds(227, 110, 185, 16);
		frame.getContentPane().add(label);
		
		JLabel lblEnterNewId = new JLabel("Enter new ID");
		lblEnterNewId.setBounds(184, 223, 185, 16);
		frame.getContentPane().add(lblEnterNewId);
		
		
		
		JLabel label_1 = new JLabel("Enter the new address ");
		label_1.setBounds(270, 349, 185, 16);
		frame.getContentPane().add(label_1);
		
		
		JLabel lblEnterFirstName = new JLabel("Enter first name");
		lblEnterFirstName.setBounds(348, 223, 185, 16);
		frame.getContentPane().add(lblEnterFirstName);
		
		
		JLabel lblEnterLastName = new JLabel("Enter last name ");
		lblEnterLastName.setBounds(184, 283, 185, 16);
		frame.getContentPane().add(lblEnterLastName);
		
		JLabel lblEnterThePhone = new JLabel("Enter the phone number");
		lblEnterThePhone.setBounds(348, 283, 185, 16);
		frame.getContentPane().add(lblEnterThePhone);
	}
}
